#include<stdio.h>
#include<stdlib.h>

struct node
{
int data;
struct node *l;
struct node *r;
};

void display(struct node*);
struct node* insert_front(struct node*,int);
struct node* delete(struct node*);

int main()
{
struct node *first = (struct node*)malloc(sizeof(struct node));
struct node *second = (struct node*)malloc(sizeof(struct node));
struct node *third = (struct node*)malloc(sizeof(struct node));
struct node *fourth = (struct node*)malloc(sizeof(struct node));


first->data = 10;
first->l = NULL;
first->r = second;

second->data = 20;
second->l = first;
second->r = third;

third->data = 30;
third->l = second;
third->r = fourth;

fourth->data = 40;
fourth->l = third;
fourth->r = NULL;

printf("forward traversal: ");
display(first);


printf("\nafter inserting: ");
first = insert_front(first,50);
display(first);

printf("\nafter delete: ");
first = delete(first);
display(first);
}

void display(struct node *first)
{
struct node *ptr;
ptr = first;

while(ptr!=NULL)
{
printf("%d, ",ptr->data);
ptr=ptr->r;
}
}



struct node* insert_front(struct node *first,int data)
{
struct node *ptr = (struct node*)malloc(sizeof(struct node));
ptr->data = data;
ptr->l = NULL;
ptr->r = NULL;


ptr->r = first;
first->l = ptr;
first = ptr;
return first;
}

struct node* delete(struct node *first)
{
struct node *temp, *p;
temp = first;
while(temp->r!=NULL)
{
temp = temp->r;
}
p=temp->l;
p->r=NULL;
free(temp);
return first;
}





